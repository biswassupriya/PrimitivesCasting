public class FloatCasting {
    float f = 234.56F;
    short s = (short)f;

    public static void main(String[] args) {
        FloatCasting fc = new FloatCasting();
        System.out.println(fc.s);
    }
}
