public class Book {
    private String title; //instance reference variables.

    public String getTitle(){
        return title;
    }

    public static void main(String[] args) {
        Book b = new Book();
        System.out.println("This book: " + b.getTitle());
        //we will get the implicit default value because we have not assinged any title
        String s = b.getTitle();
       // String t = s.toLowerCase();//throws an exception //Runtime exception
        if(s != null){
            String t = s.toLowerCase();
        }
    }
}