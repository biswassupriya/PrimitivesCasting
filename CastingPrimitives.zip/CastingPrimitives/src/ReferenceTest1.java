import java.awt.Dimension;
public class ReferenceTest1 {
    public static void main(String[] args) {
        int a = 1;

        Dimension d = new Dimension(5,10);
        ReferenceTest1 rt = new ReferenceTest1();
        System.out.println("Before modify() d.height" + "  " + d.height);
        rt.modify(d);
        System.out.println("After modify() d.height" + "  " + d.height);
       rt.modify(a);

        System.out.println("Before modify the number is " + " " + a);
        System.out.println("after modify the number is" + " " + a);



    }
    void modify(Dimension dim){
        dim.height = dim.height+1;
        System.out.println("Dim " + " "  + dim.height);
    }
    void modify(int number){
       number = number+1;
       System.out.println("number = " + number);
   }

}
