public class StringTest {
    public static void main(String[] args) {
        String s = "Java";
        String y = s;
        System.out.println("y string : " + y);
        s = s + "Bean";
        System.out.println(" y string : " + y);
        String f = "Fred";
        String t = f;
        t.toUpperCase();
        System.out.println("String t : " + t);
    }
}
