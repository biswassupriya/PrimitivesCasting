public class Layout {
    static int s = 343;
    int x;
    {
        x = 7;
        int x2 = 5;
    }
    Layout(){
        x += 8;
        int x3 = 6;
    }
    void doStuff(){
        int y = 0;
        for(int z = 0; z < 4; z++){
            y += z+x;
            System.out.println(z);
        }
    }

    public static void main(String[] args) {
        System.out.println(s);
        Layout l = new Layout();
        System.out.println(l.x);

    }
}
