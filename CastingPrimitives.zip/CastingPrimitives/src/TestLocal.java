public class TestLocal {
    public static void main(String[] args) {
        int x;
       if(args[0] != null){
            x=7;
        }
         x=6;
        int y = x;
        System.out.println(y);
    }
}
