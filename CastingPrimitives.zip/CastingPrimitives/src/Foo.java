public class Foo {
    public void doStuff(){
        System.out.println("doing Foo things");
    }
}
class Bar extends Foo{
    public void doBarStuff(){
        System.out.println("doing bar activities");
    }

    @Override
    public void doStuff() {
        System.out.println("doing bar things");

    }
}

 class Test{
     public static void main(String[] args) {
         Foo reallyABar = new Bar();
         reallyABar.doStuff();
        Foo f = new Foo();
        f.doStuff();
        Bar b = new Bar();
        b.doBarStuff();
        b.doStuff();

       // Bar reallyAFoo = new Foo();/*invalid because Foo is the parent class who cannot invoke child class */
     }
 }