public class Casting {
    public static void main(String[] args) {
        int x = (int)3957.229;
        long l = 56L;
        byte b = (byte)l;
        long g = 130L;
        byte y = (byte)g;
        float f = 99999945677.2345678f;
        short s = (short)f;
        System.out.println(x);
        System.out.println(b);
        System.out.println(y);
        System.out.println(s);
    }
}
