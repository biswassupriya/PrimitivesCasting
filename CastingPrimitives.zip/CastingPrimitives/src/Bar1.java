public class Bar1 {
    int barNum = 28;
}
class Loo1{
    Bar1 myBar = new Bar1();
    void changeIt(Bar1 myBar1){
        myBar.barNum = 99;
        System.out.println("myBar.barNum in changeIt is " + myBar.barNum);
        myBar = new Bar1();
        myBar.barNum = 420;
        System.out.println(myBar.barNum);
    }
    public static void main(String[] args) {
        Loo1 f = new Loo1();
        System.out.println(f.myBar.barNum);
        f.changeIt(f.myBar);
        System.out.println(f.myBar.barNum+ "after changeIt");
    }
}
