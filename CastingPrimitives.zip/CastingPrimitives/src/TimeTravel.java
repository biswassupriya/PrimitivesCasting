import java.util.Date;
public class TimeTravel {
    public static void main(String[] args) {
        Date date = null; // explicitly set the local reference variable
        //variable to null
        if (date == null){
            System.out.println("date is null");
        }
        int year = 2050; //local variable because the int variable is declared inside the main method and with explicit value
        int year1 ;// the year has not been initialized with any value
        int day;//declared but not initialized
        System.out.println("The year is " + year);
        //System.out.println("The year is" + year1);//compile error because the variable is a local variable so require explicit value
    }
}
