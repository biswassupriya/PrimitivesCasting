import java.awt.Dimension;
import java.awt.geom.Area;

public class ReferenceTest {
    public static void main(String[] args) {
        Dimension m = new Dimension(5,10);
        System.out.println("m.height : " + m.height);
        Dimension b = m;
        b.height = 30;
        System.out.println("m.height: " + b.height);
        System.out.println("m.width: " + m.width);
        System.out.println("Area : " + m.width*m.height);
        System.out.println(m.width+m.height);
        System.out.println(m.height/m.width);


    }
}
