public class ScopeError {
    int x = 5;

    public static void main(String[] args) {
        ScopeError se = new ScopeError();
        System.out.println( se.x++);
        se.go();
        se.go2();
        se.go3();

    }
    void go(){
        int y = 5;
        System.out.println(y);
    }
    void go2(){
       int  y=6;
        y++;
        System.out.println(y);
    }
    void go3(){
        int v =5;
        v++;
        for(int z = 0; z < 5; z++);
        //boolean test = false;
        //int z = 6;
        //if(z == 3){
         //   test = true;
            System.out.println(v);
        //}
    }
}
