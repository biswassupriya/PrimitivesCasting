public class Foo1 {
    static int size = 7;
    private Object myBar;

    static void changeIt(int size){
        size = size + 200;
        System.out.println("size is ChangeIt is " + " " + size);
    }

    public static void main(String[] args) {
        Foo1 f = new Foo1();
        System.out.println("size = "  + size);
        changeIt(size);
        System.out.println("After changeIt is " + size);
    }
}
