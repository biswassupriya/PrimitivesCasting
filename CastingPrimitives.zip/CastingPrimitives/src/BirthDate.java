public class BirthDate {
    int year;

    public static void main(String[] args) {
        BirthDate bd = new BirthDate();
        bd.showYear();

    }

    public void showYear(){
        System.out.println("This is the year: " + year);
    }
}
//output shows an implicit value which is zero the default value of the instance variable year
//if not sure about the value then even assigining with a default value then the code will be easy to read and maintain by other programmer