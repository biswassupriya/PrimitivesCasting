public class ValueTest {
    public static void main(String[] args) {
        int a = 10;
        System.out.println(a);
        int b = a;
        b = 30;
        int c = 40 + b + a;
        System.out.println(a +  " " + "After chnaging the value b");
        System.out.println(b);
        System.out.println(c);
    }
}
